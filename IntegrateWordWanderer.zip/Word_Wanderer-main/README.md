BSIT 3E<br>

78905 IT-INTPROG32 LEC TTH 1:30 PM - 2:30 PM 219<br>

78916 IT-INTPROG32 LAB TTH 3:00 PM - 4:30 PM 803<br>


MEMBERS:<br>
AYO, RYAN<br>
BESIN, JENEVA<br>
HEREDIA, KERSHEY


//CLONING THIS REPOSITORY<br>
git clone https://github.com/ryanayo74/Word_Wanderer<br>
